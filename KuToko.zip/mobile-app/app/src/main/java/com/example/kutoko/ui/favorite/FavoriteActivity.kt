package com.example.kutoko.ui.favorite

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.kutoko.R

class FavoriteActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorite)
    }
}